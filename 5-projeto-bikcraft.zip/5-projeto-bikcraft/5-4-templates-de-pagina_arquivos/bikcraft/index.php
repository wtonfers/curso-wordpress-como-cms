<?php get_header(); ?>

	<p>Página Index</p>

<?php get_footer(); ?>