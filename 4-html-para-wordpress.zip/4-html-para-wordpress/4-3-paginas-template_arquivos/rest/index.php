<?php get_header(); ?>
	<p>Usando Template Index</p>
<?php get_footer(); ?>